using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ITELECASPExercise2.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ITELECASPExercise2.Pages.Form
{
    public class InformationModel : PageModel
    {
        [BindProperty]
       public  StudentsModel  Students { set; get; }
        public void OnGet()
        {
        }

        public void OnPost()
        {
            //string fname = Request.Form["txtfname"];
            //string mname = Request.Form["txtmname"];
            //string lname = Request.Form["txtlname"];
            //string address = Request.Form["txtaddress"];
            //string age = Request.Form["txtage"];
            //string course = Request.Form["txtcourse"];
            //string year = Request.Form["txtyear"];
            HttpResponseWritingExtensions.WriteAsync(this.Response,"WELCOME" + " " + Students.Fname + " " + Students.Mname+" "+Students.Lname + " " + Students.Address + " " + Students.Age + " " + Students.Course + " " + Students.Year );
        }

    }
}


