﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ITELECASPExercise2.Model
{
    public class StudentsModel
    {
       public string Fname { set; get; }

        public string Mname { set; get; }

        public string Lname { set; get; }

        public string Age { set; get; }

        public string Address { set; get; }

        public string Gender { set; get; }

        public string Course  { set; get; }

        public string Year { set; get; }
    }
}
